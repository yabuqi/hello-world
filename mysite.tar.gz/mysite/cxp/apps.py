from django.apps import AppConfig


class CxpConfig(AppConfig):
    name = 'cxp'
